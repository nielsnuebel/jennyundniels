<?php

	// MailChimp
	$listID = "LIST-ID";
	$APIKey = "API-KEY";

	// Database
	$host = 'YOUR-HOST';
	$username = 'YOUR-USER';
	$password = 'YOUR-PASSWORD';
	$database = 'TEMPLATE-DATABASE';
	
	// Contact
	$to = 'YOUR-EMAIL-ADDRESS';
    $subject = 'Subject here...';
	
	// Variant
	$useMailChimp = "NO";

?>